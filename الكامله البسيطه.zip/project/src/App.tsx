import { Hero } from "@/components/Hero"
import { Navigation } from "@/components/Navigation"
import { About } from "@/components/About"
import { Services } from "@/components/Services"
import { Packages } from "@/components/packages/Packages"
import { Contact } from "@/components/contact/Contact"
import { Footer } from "@/components/footer/Footer"

export default function App() {
  return (
    <main className="min-h-screen bg-background">
      <Navigation />
      <Hero />
      <About />
      <Services />
      <Packages />
      <Contact />
      <Footer />
    </main>
  )
}