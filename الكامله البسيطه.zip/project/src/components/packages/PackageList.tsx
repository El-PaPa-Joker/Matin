import { useInView } from "react-intersection-observer"
import { PackageCard } from "./PackageCard"

const packages = [
  {
    name: "Bronze",
    price: 499,
    color: "#cd7f32",
    features: [
      "استشارة تغذية أولية",
      "خطة غذائية لمدة شهر",
      "متابعة أسبوعية",
      "دعم عبر الواتساب"
    ]
  },
  {
    name: "Gold",
    price: 899,
    color: "#ffd700",
    popular: true,
    features: [
      "جميع مميزات Bronze",
      "جلسة تأهيل شهرية",
      "تعديل الخطة الغذائية",
      "متابعة نصف أسبوعية",
      "قياسات الجسم الشهرية"
    ]
  },
  {
    name: "Elite",
    price: 1499,
    color: "#d4af37",
    features: [
      "جميع مميزات Gold",
      "جلستي تأهيل شهرياً",
      "برنامج تدريبي مخصص",
      "متابعة يومية",
      "تحليل مؤشرات الجسم",
      "استشارات غير محدودة"
    ]
  },
  {
    name: "VIP",
    price: 2499,
    color: "#8b0000",
    features: [
      "جميع مميزات Elite",
      "أولوية الحجز",
      "جلسات تأهيل أسبوعية",
      "تدريب شخصي أسبوعي",
      "خطة تغذية مفصلة",
      "دعم على مدار الساعة",
      "تقارير تقدم أسبوعية"
    ]
  }
]

export function PackageList() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1
  })

  return (
    <div ref={ref} className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 max-w-7xl mx-auto">
      {packages.map((pkg, index) => (
        <PackageCard
          key={pkg.name}
          {...pkg}
          index={index}
          inView={inView}
        />
      ))}
    </div>
  )
}