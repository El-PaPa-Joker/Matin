import { Check } from "lucide-react"
import { Button } from "@/components/ui/button"
import { motion } from "framer-motion"
import { cn } from "@/lib/utils"

interface PackageProps {
  name: string
  price: number
  color: string
  features: string[]
  popular?: boolean
  index: number
  inView: boolean
}

export function PackageCard({ name, price, color, features, popular, index, inView }: PackageProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={inView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.6, delay: index * 0.1 }}
      className={cn(
        "relative bg-white rounded-2xl shadow-lg overflow-hidden",
        popular && "scale-105 md:translate-y-[-1rem]"
      )}
      style={{
        borderTop: `4px solid ${color}`
      }}
    >
      {popular && (
        <div
          className="absolute top-0 right-0 px-4 py-1 text-sm font-medium text-white"
          style={{ backgroundColor: color }}
        >
          الأكثر طلباً
        </div>
      )}
      
      <div className="p-8">
        <h3 className="text-2xl font-bold mb-2" style={{ color }}>
          {name}
        </h3>
        <div className="flex items-baseline mb-6">
          <span className="text-4xl font-bold">{price}</span>
          <span className="text-lg text-gray-600 mr-2">ج.م/شهرياً</span>
        </div>
        
        <ul className="space-y-4 mb-8">
          {features.map((feature) => (
            <li key={feature} className="flex items-start gap-2 text-gray-700">
              <Check className="w-5 h-5 mt-0.5 flex-shrink-0" style={{ color }} />
              <span>{feature}</span>
            </li>
          ))}
        </ul>
        
        <Button
          variant="gradient"
          className="w-full"
          onClick={() => {
            const message = `مرحباً، أود الاستفسار عن باقة ${name}`;
            window.open(`https://wa.me/+201234567890?text=${encodeURIComponent(message)}`, "_blank");
          }}
        >
          اختر الباقة
        </Button>
      </div>
    </motion.div>
  )
}