import { Mail, Phone, MapPin, Clock } from "lucide-react"

const contactInfo = [
  {
    icon: Phone,
    label: "رقم الهاتف",
    value: "+20 123 456 7890",
    dir: "ltr"
  },
  {
    icon: Mail,
    label: "البريد الإلكتروني",
    value: "info@mateen-academy.com",
    dir: "ltr"
  },
  {
    icon: MapPin,
    label: "العنوان",
    value: "القاهرة، مصر",
    dir: "rtl"
  },
  {
    icon: Clock,
    label: "ساعات العمل",
    value: "السبت - الخميس: 9 صباحاً - 9 مساءً",
    dir: "rtl"
  }
]

export function ContactInfo() {
  return (
    <div className="bg-primary/5 rounded-2xl p-8">
      <h3 className="text-2xl font-bold text-primary mb-6">معلومات التواصل</h3>
      <div className="space-y-6">
        {contactInfo.map((info) => (
          <div key={info.label} className="flex items-start gap-4">
            <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
              <info.icon className="w-5 h-5 text-primary" />
            </div>
            <div>
              <p className="font-medium text-gray-600">{info.label}</p>
              <p className="text-gray-900" dir={info.dir}>{info.value}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}