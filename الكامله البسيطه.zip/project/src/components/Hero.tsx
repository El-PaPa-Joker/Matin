import { Button } from "@/components/ui/button"
import { motion } from "framer-motion"
import { Logo } from "@/components/Logo"

export function Hero() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-gradient-to-br from-primary to-accent py-32">
      <div className="absolute inset-0 bg-black/20" />
      
      <div className="container mx-auto px-4 relative z-10 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="max-w-4xl mx-auto"
        >
          <Logo size="large" className="mx-auto mb-8 logo-shadow" />
          
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
            رحلة صحية تبدأ مع متين
          </h1>
          <p className="text-xl md:text-2xl text-white/90 mb-8 text-balance">
            تغذية متوازنة، تأهيل متقدم، تدريب فعال
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              variant="gradient"
              size="lg"
              onClick={() => document.getElementById('packages')?.scrollIntoView()}
              className="text-lg"
            >
              استكشف الباقات
            </Button>
            <Button
              variant="outline"
              size="lg"
              onClick={() => document.getElementById('contact')?.scrollIntoView()}
              className="text-lg bg-white/10 text-white border-white/20 hover:bg-white/20"
            >
              تواصل معنا
            </Button>
          </div>
        </motion.div>
      </div>
      
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-background to-transparent" />
    </section>
  )
}