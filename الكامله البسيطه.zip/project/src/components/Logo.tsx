export function Logo({ className = "", size = "default" }: { className?: string, size?: "default" | "large" | "small" }) {
  const sizes = {
    small: "h-8",
    default: "h-12",
    large: "h-16"
  }

  return (
    <div className={`relative ${sizes[size]} aspect-[3/1] ${className}`}>
      <svg viewBox="0 0 900 300" className="h-full w-auto">
        <g transform="translate(0 0)">
          {/* Icon */}
          <g transform="translate(650 50) scale(0.8)">
            <path
              d="M150 0 C180 50 220 80 250 100 C220 120 180 150 150 200 C120 150 80 120 50 100 C80 80 120 50 150 0"
              fill="#046e8f"
            />
            <path
              d="M150 0 C165 25 195 40 220 50 C195 60 165 75 150 100 C135 75 105 60 80 50 C105 40 135 25 150 0"
              fill="#f4b400"
            />
            <circle cx="150" cy="50" r="5" fill="#f4b400" />
            <circle cx="180" cy="70" r="5" fill="#f4b400" />
            <circle cx="120" cy="70" r="5" fill="#f4b400" />
          </g>
          
          {/* Text */}
          <g transform="translate(50 100)">
            <text
              x="0"
              y="0"
              className="text-[3rem]"
              fill="#046e8f"
              style={{ fontFamily: 'Alexandria' }}
            >
              أكاديمية
            </text>
            <text
              x="0"
              y="100"
              className="text-[6rem]"
              fill="#f4b400"
              style={{ fontFamily: 'Alexandria' }}
            >
              متين
            </text>
            <text
              x="0"
              y="150"
              className="text-[1.5rem]"
              fill="#046e8f"
              style={{ fontFamily: 'Alexandria' }}
            >
              للتغذية والتدريب والتأهيل
            </text>
          </g>
        </g>
      </svg>
    </div>
  )
}