import { motion } from "framer-motion"
import { useInView } from "react-intersection-observer"
import { Check } from "lucide-react"
import { Button } from "@/components/ui/button"

const packages = [
  {
    name: "Bronze",
    price: 499,
    color: "#cd7f32",
    features: [
      "استشارة تغذية أولية",
      "خطة غذائية لمدة شهر",
      "متابعة أسبوعية",
      "دعم عبر الواتساب"
    ]
  },
  {
    name: "Gold",
    price: 899,
    color: "#ffd700",
    popular: true,
    features: [
      "جميع مميزات Bronze",
      "جلسة تأهيل شهرية",
      "تعديل الخطة الغذائية",
      "متابعة نصف أسبوعية",
      "قياسات الجسم الشهرية"
    ]
  },
  {
    name: "Elite",
    price: 1499,
    color: "#d4af37",
    features: [
      "جميع مميزات Gold",
      "جلستي تأهيل شهرياً",
      "برنامج تدريبي مخصص",
      "متابعة يومية",
      "تحليل مؤشرات الجسم",
      "استشارات غير محدودة"
    ]
  },
  {
    name: "VIP",
    price: 2499,
    color: "#8b0000",
    features: [
      "جميع مميزات Elite",
      "أولوية الحجز",
      "جلسات تأهيل أسبوعية",
      "تدريب شخصي أسبوعي",
      "خطة تغذية مفصلة",
      "دعم على مدار الساعة",
      "تقارير تقدم أسبوعية"
    ]
  }
]

export function Packages() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1
  })

  return (
    <section id="packages" className="py-24 bg-white">
      <div className="container mx-auto px-4">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="max-w-4xl mx-auto text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-6 text-primary">باقاتنا</h2>
          <p className="text-lg text-gray-600 text-balance">
            اختر الباقة المناسبة لاحتياجاتك وابدأ رحلتك نحو حياة صحية أفضل
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 max-w-7xl mx-auto">
          {packages.map((pkg, index) => (
            <motion.div
              key={pkg.name}
              initial={{ opacity: 0, y: 20 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="relative bg-white rounded-2xl shadow-lg overflow-hidden"
              style={{
                borderTop: `4px solid ${pkg.color}`
              }}
            >
              {pkg.popular && (
                <div
                  className="absolute top-0 right-0 px-4 py-1 text-sm font-medium text-white"
                  style={{ backgroundColor: pkg.color }}
                >
                  الأكثر طلباً
                </div>
              )}
              
              <div className="p-8">
                <h3 className="text-2xl font-bold mb-2" style={{ color: pkg.color }}>
                  {pkg.name}
                </h3>
                <div className="flex items-baseline mb-6">
                  <span className="text-4xl font-bold">{pkg.price}</span>
                  <span className="text-lg text-gray-600 mr-2">ج.م/شهرياً</span>
                </div>
                
                <ul className="space-y-4 mb-8">
                  {pkg.features.map((feature) => (
                    <li key={feature} className="flex items-start gap-2 text-gray-700">
                      <Check className="w-5 h-5 mt-0.5 flex-shrink-0" style={{ color: pkg.color }} />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
                
                <Button
                  variant="gradient"
                  className="w-full"
                  onClick={() => {
                    const message = `مرحباً، أود الاستفسار عن باقة ${pkg.name}`;
                    window.open(`https://wa.me/+201234567890?text=${encodeURIComponent(message)}`, "_blank");
                  }}
                >
                  اختر الباقة
                </Button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}