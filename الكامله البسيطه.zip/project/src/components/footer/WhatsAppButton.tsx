import { Button } from "@/components/ui/button"
import { MessageCircle } from "lucide-react"

export function WhatsAppButton() {
  return (
    <Button
      variant="gradient"
      size="lg"
      className="gap-2"
      onClick={() => window.open("https://wa.me/+201234567890", "_blank")}
    >
      <MessageCircle className="w-5 h-5" />
      تواصل عبر واتساب
    </Button>
  )
}