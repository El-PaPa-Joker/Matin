const links = [
  { href: "#", label: "الرئيسية" },
  { href: "#about", label: "من نحن" },
  { href: "#services", label: "خدماتنا" },
  { href: "#packages", label: "الباقات" },
  { href: "#contact", label: "تواصل معنا" }
]

export function QuickLinks() {
  return (
    <nav className="flex flex-wrap gap-6">
      {links.map((link) => (
        <a
          key={link.label}
          href={link.href}
          className="text-gray-600 hover:text-primary transition-colors"
        >
          {link.label}
        </a>
      ))}
    </nav>
  )
}