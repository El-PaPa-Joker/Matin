import { Facebook, Instagram, Twitter, Youtube } from "lucide-react"

const socialLinks = [
  {
    icon: Facebook,
    href: "https://facebook.com",
    label: "Facebook"
  },
  {
    icon: Instagram,
    href: "https://instagram.com",
    label: "Instagram"
  },
  {
    icon: Twitter,
    href: "https://twitter.com",
    label: "Twitter"
  },
  {
    icon: Youtube,
    href: "https://youtube.com",
    label: "Youtube"
  }
]

export function SocialLinks() {
  return (
    <div className="flex items-center gap-4">
      {socialLinks.map((social) => (
        <a
          key={social.label}
          href={social.href}
          target="_blank"
          rel="noopener noreferrer"
          className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center transition-colors hover:bg-primary/20"
          aria-label={social.label}
        >
          <social.icon className="w-5 h-5 text-primary" />
        </a>
      ))}
    </div>
  )
}