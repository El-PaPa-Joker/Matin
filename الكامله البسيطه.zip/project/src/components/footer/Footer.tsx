import { Logo } from "@/components/Logo"
import { SocialLinks } from "./SocialLinks"
import { QuickLinks } from "./QuickLinks"
import { WhatsAppButton } from "./WhatsAppButton"

export function Footer() {
  const currentYear = new Date().getFullYear()

  return (
    <footer className="bg-white pt-16 pb-8">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          {/* Logo and Description */}
          <div className="space-y-4">
            <Logo size="small" />
            <p className="text-gray-600">
              نقدم خدمات متكاملة في مجالات التغذية والتأهيل والتدريب لمساعدتك في تحقيق أهدافك الصحية
            </p>
            <SocialLinks />
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-bold mb-4">روابط سريعة</h3>
            <QuickLinks />
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="text-lg font-bold mb-4">معلومات التواصل</h3>
            <div className="space-y-2">
              <p className="text-gray-600">القاهرة، مصر</p>
              <p className="text-gray-600 ltr">+20 123 456 7890</p>
              <p className="text-gray-600 ltr">info@mateen-academy.com</p>
            </div>
          </div>

          {/* WhatsApp Button */}
          <div className="flex flex-col justify-between">
            <div>
              <h3 className="text-lg font-bold mb-4">تواصل معنا</h3>
              <p className="text-gray-600 mb-4">
                نحن هنا لمساعدتك. تواصل معنا عبر واتساب للحصول على استشارة مجانية
              </p>
            </div>
            <WhatsAppButton />
          </div>
        </div>

        {/* Copyright */}
        <div className="border-t pt-8 text-center">
          <p className="text-gray-600">
            جميع الحقوق محفوظة © {currentYear} أكاديمية متين
          </p>
        </div>
      </div>
    </footer>
  )
}