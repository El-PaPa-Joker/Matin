import { motion } from "framer-motion"
import { useInView } from "react-intersection-observer"
import { Salad, Activity, Dumbbell } from "lucide-react"
import { Button } from "@/components/ui/button"

const services = [
  {
    icon: Salad,
    title: "التغذية",
    description: "خطط غذائية مخصصة تناسب احتياجاتك وأهدافك الصحية، مع متابعة مستمرة ودعم متواصل.",
    features: [
      "تحليل شامل للنظام الغذائي",
      "خطط وجبات متوازنة",
      "نصائح غذائية مخصصة",
      "متابعة أسبوعية للتقدم"
    ]
  },
  {
    icon: Activity,
    title: "التأهيل",
    description: "برامج تأهيل متخصصة لتحسين الحركة والأداء البدني، مع تقنيات متقدمة وخبرة موثوقة.",
    features: [
      "تقييم حالة المفاصل والعضلات",
      "تمارين تأهيلية مخصصة",
      "علاج طبيعي متقدم",
      "خطة تعافي متكاملة"
    ]
  },
  {
    icon: Dumbbell,
    title: "التدريب",
    description: "برامج تدريبية شاملة لتحسين اللياقة البدنية وبناء القوة، مع مدربين محترفين.",
    features: [
      "تدريب شخصي مخصص",
      "برامج لياقة متكاملة",
      "تمارين قوة وتحمل",
      "متابعة مستمرة للأداء"
    ]
  }
]

export function Services() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1
  })

  return (
    <section id="services" className="py-24 bg-gray-50">
      <div className="container mx-auto px-4">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="max-w-4xl mx-auto text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-6 text-primary">خدماتنا</h2>
          <p className="text-lg text-gray-600 text-balance">
            نقدم مجموعة متكاملة من الخدمات المصممة خصيصاً لتلبية احتياجاتك الصحية والبدنية
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {services.map((service, index) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 20 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: index * 0.2 }}
              className="bg-white rounded-2xl shadow-lg overflow-hidden"
            >
              <div className="p-8">
                <div className="w-16 h-16 mx-auto mb-6 rounded-xl bg-primary/10 flex items-center justify-center">
                  <service.icon className="w-8 h-8 text-primary" />
                </div>
                <h3 className="text-2xl font-bold mb-4 text-gray-900">{service.title}</h3>
                <p className="text-gray-600 mb-6 text-balance">{service.description}</p>
                <ul className="space-y-3 text-right mb-8">
                  {service.features.map((feature) => (
                    <li key={feature} className="flex items-center gap-2 text-gray-700">
                      <span className="w-1.5 h-1.5 rounded-full bg-accent flex-shrink-0" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
                <Button
                  variant="gradient"
                  className="w-full"
                  onClick={() => window.open("https://wa.me/+201234567890", "_blank")}
                >
                  احجز الآن
                </Button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}